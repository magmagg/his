<?php
  if (!defined('BASEPATH'))exit('No direct script access allowed');
  class Model_appointment extends CI_Model{






  }
