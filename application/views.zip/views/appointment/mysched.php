
<!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <div class="row">
                  <aside class="col-lg-3">
                      <h4 class="drg-event-title"> My schedules</h4>
                      <div id='external-events'>
                          <div class='external-event label label-primary'>My Event 1</div>
                          <div class='external-event label label-success'>My Event 2</div>
                          <div class='external-event label label-info'>My Event 3</div>
                          <div class='external-event label label-inverse'>My Event 4</div>
                          <div class='external-event label label-warning'>My Event 5</div>
                          <div class='external-event label label-danger'>My Event 6</div>
                          <div class='external-event label label-default'>My Event 7</div>
                          <div class='external-event label label-primary'>My Event 8</div>
                          <div class='external-event label label-info'>My Event 9</div>
                          <div class='external-event label label-success'>My Event 10</div>
                          <p class="border-top drp-rmv">
                              <input type='checkbox' id='drop-remove' />
                              remove after drop
                          </p>
                      </div>
                      <div class="col-sm-12">
                            <section class="panel">

                                <table class="table table-hover">
                                    <thead>
                                    <tr>
                                        <th>Mon</th>
                                        <th>Tues</th>
                                        <th>Wed</th>
                                        <th>Thurs</th>
                                        <th>Fri</th>
                                        <th>Sat</th>
                                        <th>Sun</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>9-10 am</td>
                                        <td>9-10 pm</td>
                                        <td>Otto</td>
                                        <td>@mdo</td>
                                        <td>@mdo</td>
                                        <td>@mdo</td>
                                        <td>@mdo</td>
                                    </tr>

                                    </tbody>
                                </table>
                            </section>
                        </div>
                    </div>
              </div>
              <!-- page end-->
          </section>
      </section>
      <!--main content end-->


      <
