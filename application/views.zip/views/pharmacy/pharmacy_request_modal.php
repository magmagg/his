<div class="modal fade " id="confirm-submit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Confirm submit</h4>
            </div>
            <div class="modal-body">

            Are you sure with your pharmacy request?
                           </table>  </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a href="#" id="submitme" class="btn btn-success success">Submit</a>
            </div>
        </div>
    </div>
</div>
