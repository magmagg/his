<div class="modal fade" id="confirm-reject" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Reject request
            </div>
            <div class="modal-body">
                Reject this request?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a style="margin-top: -5px;" class="btn btn-danger btn-ok">Reject</a>
            </div>
        </div>
    </div>
</div>
