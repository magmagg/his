INSERT INTO `users` (`user_id`, `type_id`, `username`, `password`, `email`, `first_name`, `last_name`, `middle_name`, `birthdate`, `contact_number`, `gender`, `status`, `employment_date`, `dept`) VALUES
('USER-00005', 1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin@gmail.com', 'admin', 'admin', 'admin', '1969-07-11', '09065555555', 'm', 1, '1999-07-11', 'DEPT-0001'),
('USER-00008', 5, 'megmeg_1015', '81323d4a8b7385d92825f42404dfaea0544c9742', 'meg_1510@yahoo.com', 'Margarette', 'Rey', 'Cagungun', '2002-10-15', '09888888888', 'F', 1, '2016-07-05', 'DEPT-0005'),
('USER-00009', 5, 'andreabbbb', '81323d4a8b7385d92825f42404dfaea0544c9742', 'brillantesaa@yahoo.com', 'Andrea', 'Brillantes', 'Rey', '1990-08-07', '09777777777', 'F', 1, '2016-07-05', 'DEPT-0005'),
('USER-00010', 5, 'nicoleee01', '81323d4a8b7385d92825f42404dfaea0544c9742', 'nicolealexis@yahoo.com', 'Nicole', 'Cleofas', 'Golingo', '1985-09-27', '09444444444', 'M', 1, '2016-07-05', 'DEPT-0005'),
('USER-00011', 5, 'alexiiiiis', '81323d4a8b7385d92825f42404dfaea0544c9742', 'alexisrr@yahoo.com', 'Alexis', 'Revilla', 'Rey', '1984-02-16', '09111111111', 'M', 1, '2016-07-05', 'DEPT-0005'),
('USER-00012', 5, 'stormeng', '81323d4a8b7385d92825f42404dfaea0544c9742', 'stormy_16@yahoo.com', 'Storm', 'Sawyer', 'Sisig', '1986-01-06', '09666666666', 'M', 1, '2016-07-05', 'DEPT-0005'),
('USER-00013', 5, 'nestlieesan', '81323d4a8b7385d92825f42404dfaea0544c9742', 'annecleo@yahoo.com', 'Nestlie', 'Cleofas', 'Revilla', '1990-06-30', '09666666666', 'F', 1, '2016-07-05', 'DEPT-0005'),
('USER-00014', 5, 'motmot12', '81323d4a8b7385d92825f42404dfaea0544c9742', 'motrey123@yahoo.com', 'Ian', 'Rey', 'Martin', '1982-12-25', '09222222222', 'M', 1, '2016-07-05', 'DEPT-0005');
