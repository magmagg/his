INSERT INTO `user_type` (`type_id`, `name`, `description`) VALUES
(1, 'Administrator', 'Can manage all features in systems'),
(2, 'Doctor', 'Edi Doctor'),
(3, 'Nurse Manager', 'Nurse Manager'),
(4, 'Charge Nurse', 'Charge Nurse'),
(5, 'Bedside Nurse', 'Bedside Nurse'),
(6, 'Radiologist', 'Radiologist'),
(7, 'Pharmacist', 'Pharmacist'),
(8, 'LABORATORY PEOPLE', 'LABORATORY PEOPLE'),
(9, 'Purchasing Staff', 'Purchasing Staff'),
(10, 'Accounting Staff', 'Accounting Staff'),
(11, 'CSR Staff', 'CSR Staff');
