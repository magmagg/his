<div class="modal fade" id="confirm-accept" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                Accept request
            </div>
            <div class="modal-body">
              Accept this request?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <a style="margin-top: -5px;" class="btn btn-success btn-ok">Accept</a>
            </div>
        </div>
    </div>
</div>
