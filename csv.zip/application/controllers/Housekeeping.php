<?php
if (!defined('BASEPATH'))exit('No direct script access allowed');
  class HouseKeeping extends CI_Controller{
    function
  }
?>
